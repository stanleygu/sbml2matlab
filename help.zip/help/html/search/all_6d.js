var searchData=
[
  ['matlaberror',['MatlabError',['../class_matlab_error.html',1,'']]],
  ['matlabtranslator',['MatlabTranslator',['../class_matlab_translator.html',1,'MatlabTranslator'],['../class_matlab_translator.html#a08f25f35cfda40bb37ecb02853bd8f8b',1,'MatlabTranslator::MatlabTranslator()']]]
];
